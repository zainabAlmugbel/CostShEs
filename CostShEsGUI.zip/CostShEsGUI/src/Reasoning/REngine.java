package Reasoning;

import org.ruleml.oojdrew.TopDown.BackwardReasoner;
import org.ruleml.oojdrew.parsing.POSLParser;
import org.ruleml.oojdrew.parsing.RDFSParser;
import org.ruleml.oojdrew.parsing.RuleMLFormat;
import org.ruleml.oojdrew.parsing.RuleMLParser;
import org.ruleml.oojdrew.util.*;

import com.sun.org.apache.xml.internal.dtm.ref.DTMDefaultBaseIterators.TypedAncestorIterator;

import org.apache.log4j.Level;
import org.ruleml.oojdrew.*;

import javax.xml.transform.*;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import userInput.Uinput;

import javax.swing.tree.*;


import java.io.File;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import javax.swing.tree.DefaultTreeModel;
public class REngine {
	
	
	
	
	// change followings:
	//it name and its arguments
	//this function must take three arguments 
	//as input: facts, rules, and Query
	public static String callEngine(String patient, String Rdata, String Query, String membership, String BL) throws Exception{		
		StringBuilder Solution=new StringBuilder();
		try{
            System.out.println("inside 1..... \n");


			Solution.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
"<?xml-model href=\"http://deliberation.ruleml.org/1.01/relaxng/datalogplus_min_relaxed.rnc\"?>"+
"<?xml-stylesheet type=\"text/xsl\" href=\"GrailogKSViz.xslt\"?>"+
"<RuleML>"+"<Assert mapClosure=\"universal\">");
		    //create a BR	
			BackwardReasoner br = new BackwardReasoner();
			
			//The solution iterator contains all the solutions
		    Iterator solit = null;
		    
            

		    //dc is the Definitive clause that contians the query
		    DefiniteClause dc = null;
		    
		    //Reset the Internal Symbol Table for predicates and types
		    SymbolTable.reset();
		    
		    //Config
		    Config conf=new Config(REngine.class);
		    conf.setSelectedRuleMLFormat(RuleMLFormat.RuleML100);
		    
		    conf.setLogLevel(Level.ALL);
		    //Configuration 
		    Configuration con=conf;
            

		    //create a RuleML parser         
		    RuleMLParser rp = new RuleMLParser(con);
		    
		    //Store your KB here in RuleML
		    String kbstr = Rdata;//" test(a). \n test(b).";
		   
		    String content = new String(Files.readAllBytes(Paths.get("Taxonomy.rdfs")));

		    //store types here   
		    String typestr = content;  
            
	    //reset the type information
		    Types.reset();
		    
		    //parse types in RDF
		   // empty it causes problem therefore I commented it
		    RDFSParser.parseRDFSString(content);
//System.out.println("confirm types" +Types.isTypeDefined("Sel"));
		    //parse the knowledge base in ruleml          
		   
		    rp.parseRuleMLString(kbstr);

		    //load the clauses from the parser into the backward reasoner 
			br.loadClauses(rp.iterator());
			
			
			////////
			//DEBUG Loop to print out all the clauses in the system
		    Iterator it = rp.iterator();
		    //System.out.println("ccccc"+rp.iterator().next().toString());
		    while (it.hasNext()) {
		    	DefiniteClause d = (DefiniteClause) it.next();
		    	//System.out.println("Loaded clause: " + d.toString());//toPOSLString());
		    }	
		    //DEBUG 
		    
		    //Create a backward reasoner from the clauses
			br = new BackwardReasoner(br.clauses, br.oids);
			
			//query string
		   // String query = Query;
		    
			 
		    //parse the query
		    dc = rp.parseRuleMLQuery(Query);
		    
		    //execute the query
		 	solit = br.iterativeDepthFirstSolutionIterator(dc);
		 	
		 	//display the results
		 	Vector data = new Vector();
		    int varSize = 0;
		   // StringBuilder Solution=new StringBuilder();
		        while(solit.hasNext()) {

		            BackwardReasoner.GoalList gl = (BackwardReasoner.GoalList) solit.
		                                           next();
		            Hashtable varbind = gl.varBindings;

		            javax.swing.tree.DefaultMutableTreeNode root = br.toTree();
		            root.setAllowsChildren(true);

		            javax.swing.tree.DefaultTreeModel dtm = new DefaultTreeModel(root);
					
		            int i = 0;
		            Object[][] rowdata = new Object[varbind.size()][2];
		            varSize = varbind.size();
		            
		            Enumeration e = varbind.keys();
		            //System.out.println("Solution..... \n");
		            //for the solution in RuleML
		            
		           
		           // Solution.append("<RuleML>\n");
		            
		            Solution.append("<Atom>\n");
		            Solution.append("<Rel>costSharingEstimator</Rel>\n");
		            Solution.append("<Ind>"+membership+"</Ind>\n");
		            Solution.append("<Ind>"+BL+"</Ind>\n");
		            while (e.hasMoreElements()) {
		                Object k = e.nextElement();
		                Object val = varbind.get(k);
		                String ks = (String) k;
		                rowdata[i][0] = ks;
		                rowdata[i][1] = val;
		                
		              //  System.out.println("Variable: " + ks + " Value: " + val);
		                Solution.append("<Ind>"+val+"</Ind>\n");
		                i++;
		            }
		           
		            Solution.append("</Atom>\n"); 
		         
		            
					data.addElement(rowdata);
		        }  
		        Solution.append("</Assert>\n");  
	            Solution.append("</RuleML>\n");
		          
		    }

		    catch(Exception e){
		    	 System.out.println(e.toString());
		            System.out.println("ERRor..... \n");

		    }
		return Solution.toString();    
	}
}
