package Knowlegebase;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.LinkedList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;


public class ParseRuleMLClass {
	
	 
	public StringBuilder data;
	//public StringBuilder RMNameSpace;
	public LinkedList Newurl;
	
	public void parseRuleMLFile(String Facts,ArrayList RMNameSpaceList,StringBuilder RMData,LinkedList UrlList) throws Exception{
	
		DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();

		Document doc= dBuilder.parse(new ByteArrayInputStream(Facts.getBytes()));
		parseRuleMLTag(doc, RMNameSpaceList);
		//System.out.println("name space: "+RMNameSpace);
		
		parseAtom(doc,RMData,UrlList);
		
	}
	
	
	// parse ruleml to get name space attribute to form global ruleml
	public void parseRuleMLTag(Document doc,ArrayList RMNameSpaceList) throws Exception{
		
			//RMNameSpace=new StringBuilder();
			Element e = doc.getDocumentElement();//(Element)node;
			//System.out.println("root of xml file 2" + e.getNodeName());
			NamedNodeMap AllAtt = e.getAttributes();
			//RMNameSpace.append("<" +e.getNodeName()+" ");
			for(int i=0;i<AllAtt.getLength();i++)
				{
				Node att=AllAtt.item(i);
				String attInfo=att.getNodeName()+" = \""+ att.getNodeValue()+"\" ";
				//collect distinct name spaces in one string
				if(RMNameSpaceList.contains(attInfo)==false)
				 RMNameSpaceList.add(attInfo);				
				}
			//close ruleml open tag
			//RMNameSpace.append(" >");
			//System.out.println("RMNameSpace:::"+RMNameSpace);
			//return RMNameSpace.toString();
			}
	
	
	// parse atom to get its child to form linked data	
	
	//get all the included facts and append current facts to contain them
	public void parseAtom(Document doc,StringBuilder RMData,LinkedList UrlList) {
		 data = new StringBuilder();
		// Newurl= new LinkedList();
		try {


// the doc contains new url
// if it does , check if the url (address) exist in urlList
//	if list contains this url, ignore  url old
// else gethttp is used to get the doc of the new url
// the old doc is append to contain the new doc
// from where to append starting <Atom> without <Assert> and <RuleML>
		
//		create list of new url contains the unique new url found in facts
// compare the content of this list with urllist content
// if url not found in urlList, its facts must be parsed and added to the fact file
		
		
		//System.out.println("root of xml file " + doc.getDocumentElement().getNodeName());//<Ruleml>
		NodeList AtomNodeList = doc.getElementsByTagName("Atom");
		//iterate for the tag name Atom
		for(int index=0; index<AtomNodeList.getLength();index++ )
		{
		Element el=(Element)AtomNodeList.item(index);
		NodeList allChild= el.getChildNodes();
		//System.out.println("node name for outside el"+el.getNodeName()); //<Atom>
		RMData.append("<"+el.getNodeName()+">");
		//node name is ruleml tag rel, ind, atom, etc
		//textcontent in the text / tag value, such as client
		//nodeValue = LocalName= null
		for (int j = 0; j < allChild.getLength(); j++) {
			  //Element fileElement = (Element) allChild.item(j);
			NamedNodeMap AllAtt = allChild.item(j).getAttributes();
			
			if (AllAtt!=null)
				{
				Node att=AllAtt.item(0);
				//Add the open of the current tags Rel/Ind and its attribute
				if(allChild.item(j).getNodeName()=="Rel")
				{
					RMData.append("<"+allChild.item(j).getNodeName()+">");
					//add the value of the tag
					RMData.append(allChild.item(j).getTextContent());
					//close tag
					RMData.append("</"+allChild.item(j).getNodeName()+">");
				}
				else
				{
					RMData.append("<"+allChild.item(j).getNodeName()+" ");
					for(int x=0;x<AllAtt.getLength();x++)
					if(AllAtt.getLength()==1)
						RMData.append(att.getNodeName()+"="+"\""+att.getNodeValue()+"\"");
					else
						RMData.append(AllAtt.item(x).getNodeName()+"="+"\""+AllAtt.item(x).getNodeValue()+"\" ");
				//close the attribute tag in both conditions
					RMData.append(">");
					//check attribute type
				String AttV=att.getNodeValue();
				if (AttV.contains("url"))
					if(UrlList.contains(allChild.item(j).getTextContent())==false)
						UrlList.add(allChild.item(j).getTextContent());
				
				//add the value of the tag
				RMData.append(allChild.item(j).getTextContent());
				//close tag
				RMData.append("</"+allChild.item(j).getNodeName()+">");
				//System.out.println("child:"+ allChild.item(j).getNodeName()+
					//	" : "+ allChild.item(j).getTextContent()+ " : "+
					//	att.getNodeName()+"="+att.getNodeValue());
				
				}
				}
			
		
		}
		RMData.append(" </Atom>\n");
		}
		
		} catch (Exception ex) {
		ex.printStackTrace();
		}
	
		
		
		}

		private static String getValue(String tag, Element element) {
		NodeList nodes = element.getElementsByTagName(tag).item(0).getChildNodes();
		Node node = (Node) nodes.item(0);
		return node.getNodeValue();
		}


}
