package Knowlegebase;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import userInput.Uinput;

import Reasoning.REngine;

public class GetKnowledge {
	
	public String RuleMLHeader; // this include the name spaces
	public String facts(String MID)
	{
		 //form the data 
        StringBuilder fullData=new StringBuilder("");
			        try {
			        	String RMNameSpace;
			        	StringBuilder RMData=new StringBuilder();
			        	String fact1;
			        	String linkedData="";
			    		String url="http://localhost:90/"+java.net.URLEncoder.encode(MID, "UTF-8")+".xml";
			    	       HttpURLConnectionClass http = new HttpURLConnectionClass();

			    	        //System.out.println("Client Knowledge base");

				fact1= http.sendGet(url);
				linkedData.concat("");
				LinkedList urlList= new LinkedList();
				LinkedList checkedurlList= new LinkedList();

				ArrayList RMNameSpaceList=new ArrayList();
				//list contains all url to check if they have been added or not
				checkedurlList.push(url);
				ParseRuleMLClass pf=new ParseRuleMLClass();
    	        System.out.println("call Parsing in knowledgebase");
    	        pf.parseRuleMLFile(fact1, RMNameSpaceList,RMData,urlList);
    	        //check if there is new url
    	        //for (int j=0;j<urlList.size();j++)
    	        
    	        while(urlList.isEmpty()==false)
    	        {
    	        	String Newurl=urlList.pop().toString();//get(j).toString();
    	        	System.out.println("NewURL "+Newurl + " J: Size= "+0+":"+urlList.size());
    	        	//encode url2
    	        /*	int dl=Newurl.lastIndexOf("/");//dash location
    	        	int pl=Newurl.lastIndexOf(".xml");//dash location
    	        	String url2P1=Newurl.substring(0, dl);//url
    	        	String url2P2=Newurl.substring(dl, pl);//file name
    	        	
    	        String url2=url2P1+"/"+java.net.URLEncoder.encode(url2P2, "UTF-8")+".xml";*/

    	        	String url2=Newurl;
    	        	if(checkedurlList.contains(url2)==false)
    	        	{
    	        		fact1= http.sendGet(url2);
        	        	pf.parseRuleMLFile(fact1,RMNameSpaceList,RMData,urlList);
        	        	checkedurlList.push(url2);
    	        	}
    	        }
    	        RMNameSpace= RMNameSpaceList.toString();
    	        RMNameSpace=RMNameSpace.replace("[", "");
    	        RMNameSpace=RMNameSpace.replace(",", "");
    	        RMNameSpace=RMNameSpace.replace("]", "");
    	       // System.out.println("after call Parsing new namespace "+RMNameSpace);
    	       // System.out.println("after call Parsing new data "+RMData.length()+" : ");
    	        PrintWriter out = new PrintWriter("filedata");
    	        out.println(RMData.toString());
    	        out.close();
    	        //form the data 
    	        //StringBuilder fullData=new StringBuilder("");
	        	
	        	fullData.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?> ");
	        	fullData.append("<RuleML ");
	        	fullData.append(RMNameSpace);
	        	fullData.append("> <Assert> <And mapClosure=\"universal\"> ");
	        	fullData.append(RMData);
	        	

    	       //get rules
    	        url="http://localhost:90/Rules.xml";
	    	    http = new HttpURLConnectionClass();
	    	    fullData.append(http.sendGet(url));
	    	  
	    	    
	    	    
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			        return fullData.toString();

	}
	
	//form query
	
		public  String buildQuery(String PName,String treatingCat, String membership, String BLocation)
		{
			
			String Query="";
			if (treatingCat.trim().equals("Self"))
			{
					Query=
			"<Query>"+
	         "<Atom>"+
	            "<Rel>costSharingEstimator</Rel>"+
	            "<Ind>"+membership+"</Ind>"+
	            "<slot><Ind>insured</Ind><Var type=\"Self\"/></slot>";
				if (PName.isEmpty())
				Query+="<Var>name</Var>";
				else
					Query+="<Ind>"+PName+"</Ind>";	
				Query+=
	            "<Var>InsCompany</Var>"+
	            "<Var>Hospital</Var>"+
	            "<Ind>"+BLocation+"</Ind>"+
	            "<Var>RequiredTreatment</Var>"+
	            "<Var type=\"Integer\">Payment</Var>"+
	         "</Atom>"+
	  "</Query>";
			}
			else
			{
				Query=
						"<Query>"+
				         "<Atom>"+
				            "<Rel>costSharingEstimator</Rel>"+
				            "<Ind>"+membership+"</Ind>"+
				            "<slot><Ind>insured</Ind><Ind type=\""+treatingCat.trim()+"\">insured</Ind></slot>";
				if (PName.isEmpty())
				Query+="<Var>name</Var>";
				else
					Query+="<Ind>"+PName+"</Ind>";	
				Query+=   "<Var>InsCompany</Var>"+
				            "<Var>Hospital</Var>"+
				            "<Ind>"+BLocation+"</Ind>"+
				            "<Var>RequiredTreatment</Var>"+
				            "<Var type=\"Integer\">Payment</Var>"+
				         "</Atom>"+
				  "</Query>";	
				
			}
			
			return Query;
			
		}
	public void	formRuleMLHeader(String localRuleML)
	{
		
		
		
		
	}
}
