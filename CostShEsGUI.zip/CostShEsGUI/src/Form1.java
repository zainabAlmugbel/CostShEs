import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Label;

import java.io.File;
import java.io.PrintWriter;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.eclipse.swt.SWT;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Text;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.ui.forms.widgets.FormToolkit;
import org.eclipse.ui.forms.widgets.FormText;
import org.eclipse.swt.events.KeyAdapter;
import org.eclipse.swt.events.KeyEvent;
import userInput.Uinput;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;

import Knowlegebase.GetKnowledge;
import Reasoning.REngine;
import org.eclipse.wb.swt.SWTResourceManager;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.browser.Browser;

//import Knwolegebase.GetKnowledge;

public class Form1 {

	protected Shell shlCostshes;
	private Text MNumtext;
	private Combo BLocationList;
	private final FormToolkit formToolkit = new FormToolkit(Display.getDefault());
	private Text ResultText;
	private Text PatientName;
String Solution;
	/**
	 * Launch the application.
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Form1 window = new Form1();
			window.open();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Open the window.
	 */
	public void open() {
		Display display = Display.getDefault();
		createContents();
		shlCostshes.open();
		shlCostshes.layout();
		while (!shlCostshes.isDisposed()) {
			if (!display.readAndDispatch()) {
				display.sleep();
			}
		}
	}

	/**
	 * Create contents of the window.
	 */
	protected void createContents() {
		shlCostshes = new Shell();
		shlCostshes.setSize(858, 897);
		shlCostshes.setText("CostShEs Application");
		
		
		Label lblMembershipNumber = new Label(shlCostshes, SWT.NONE);
		lblMembershipNumber.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblMembershipNumber.setBounds(35, 108, 404, 47);
		lblMembershipNumber.setText("Membership Number:");
		
		Label lblNewLabel = new Label(shlCostshes, SWT.NONE);
		lblNewLabel.setBackground(SWTResourceManager.getColor(SWT.COLOR_WHITE));
		lblNewLabel.setBounds(35, 354, 404, 49);
		lblNewLabel.setText("Body Location:");
		
		Label lblEnterTheFollowing = new Label(shlCostshes, SWT.NONE);
		lblEnterTheFollowing.setBounds(35, 35, 558, 44);
		lblEnterTheFollowing.setText("Enter the following information");
		
		MNumtext = new Text(shlCostshes, SWT.BORDER);
		MNumtext.setBounds(446, 105, 231, 50);
		
		BLocationList = new Combo(shlCostshes, SWT.DEFAULT);
		BLocationList.setItems(new String[] {"teeth"});
		BLocationList.setBounds(446, 351, 231, 52);
		BLocationList.select(0);
		
		Button btnVisulaize = formToolkit.createButton(shlCostshes, "Visualize", SWT.NONE);
		btnVisulaize.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				//wit the solution into a file
				try{
			      PrintWriter out = new PrintWriter("filedata.xml");
	  	        out.println(Solution.toString());
	  	        out.close();
			        TransformerFactory transformerFactory = TransformerFactory.newInstance();
			        Transformer transformer = transformerFactory.newTransformer(new StreamSource(new File("GrailogKSViz.xslt")));
			        transformer.transform(new StreamSource(new File("filedata.xml")), new StreamResult("result.html"));
				}
				catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnVisulaize.setBounds(337, 451, 223, 54);
		
		ResultText = formToolkit.createText(shlCostshes, "New Text", SWT.WRAP | SWT.V_SCROLL);
		ResultText.setText("");
		ResultText.setBounds(68, 532, 666, 231);
		
		Label lblTreating = new Label(shlCostshes, SWT.NONE);
		lblTreating.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblTreating.setText("Patient:");
		lblTreating.setBounds(35, 189, 404, 52);
		formToolkit.adapt(lblTreating, true, true);
		
		Combo combotreat = new Combo(shlCostshes, SWT.READ_ONLY);
		combotreat.setItems(new String[] {"Self", "Spouse", "Daughter", "Son", "NonInsured"});
		combotreat.setBounds(446, 189, 231, 52);
		formToolkit.adapt(combotreat);
		formToolkit.paintBordersFor(combotreat);
		combotreat.select(0);
		
		Label lblName = new Label(shlCostshes, SWT.NONE);
		lblName.setBackground(SWTResourceManager.getColor(SWT.COLOR_GRAY));
		lblName.setText("Patient Name:");
		lblName.setBounds(35, 280, 404, 50);
		formToolkit.adapt(lblName, true, true);
		
		PatientName = new Text(shlCostshes, SWT.BORDER);
		PatientName.setBounds(446, 280, 231, 50);
		formToolkit.adapt(PatientName, true, true);
		

		Button btnResult = new Button(shlCostshes, SWT.NONE);
		btnResult.setBounds(68, 451, 223, 54);
		btnResult.setText("Result");

		btnResult.addSelectionListener(new SelectionAdapter() {
			public void widgetSelected(SelectionEvent e) {
				//get the user input
				Uinput in=new Uinput();
				in.setMID(MNumtext.getText().toString());
				in.setBL(BLocationList.getItem(BLocationList.getSelectionIndex()).toString());
				//use the user input to identify RuleML files (knowledge and rules)
				GetKnowledge gkb=new GetKnowledge() ;
				String datarules=gkb.facts(in.getMID());
				
				//form the query
				String patient=combotreat.getItem(combotreat.getSelectionIndex()).toString().trim();
				String PName=PatientName.getText().trim().toString();
				if (patient.equals("Son")||patient.equals("Spouse")||patient.equals("Daughter"))
				//{
					datarules=datarules.replace("Dependent", patient);
					//}
				//else
				//{datarules=datarules.replace("InsuredPerson", "Insured");}
					
				String Query=gkb.buildQuery(PName,patient,in.getMID(), in.getBL());
				//System.out.println("Query..."+Query);
				//send the knowledge base, rules and query to OOjDREW
				//retrieve result from the OOjDREW (Reasoning Class)
				
				//use oo jdrew to query the data and query
	    	    //REngine eng=new REngine();
	    	    try {
					//System.out.println("1..."+in.getMID()+in.getBL());

	    	    Solution=REngine.callEngine(patient,datarules, Query, in.getMID(),in.getBL());
					System.out.println("2...");

				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				///to print out the result
				ResultText.setText(Solution);
			}
		});
		
		
	}
	public String[] getBLocationListItems() {
		return BLocationList.getItems();
	}
	public void setBLocationListItems(String[] items) {
		BLocationList.setItems(items);
	}
}
