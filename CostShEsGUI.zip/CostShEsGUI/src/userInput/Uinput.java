package userInput;

public class Uinput {
String MID; //membership ID
String BL; // body location

public String getMID(){return MID;}

public void setMID(String ID){MID=ID;}

public String getBL(){return BL;}

public void setBL(String UBL){BL=UBL;}

}
